package com.ilham.movapps.Sign.signin

class User {

    var email: String ?=""
    var nama: String ?=""
    var password: String ?=""
    var url: String ?=""
    var username: String ?=""
    var saldo: String ?=""

}